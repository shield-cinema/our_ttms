create
    definer = root@localhost procedure ticket_refund(IN ticketId mediumtext)
BEGIN
	UPDATE ticket SET ticket_status=0 WHERE ticket_id=ticketId;
	UPDATE ticket SET ticket_locked_time='2020-01-01 00:00:00' WHERE ticket_id=ticketId;
	UPDATE customer_order SET order_status=-1 WHERE ticket_id=ticketId;
    END;

