create
    definer = root@localhost procedure ticket_lock(IN ticketId mediumtext, IN schedId mediumtext, IN locked_time datetime)
BEGIN
	UPDATE ticket SET ticket_status=1 WHERE ticket_id=ticketId AND sched_id=schedId;
	UPDATE ticket SET ticket_locked_time=locked_time WHERE ticket_id=ticketId AND sched_id=schedId;
    END;

