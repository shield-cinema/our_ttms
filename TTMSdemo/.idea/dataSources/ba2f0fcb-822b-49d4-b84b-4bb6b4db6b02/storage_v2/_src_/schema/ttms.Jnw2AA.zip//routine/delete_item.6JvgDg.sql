create
    definer = root@localhost procedure delete_item(IN ticketId mediumtext)
BEGIN
	DELETE FROM sale_item WHERE ticket_id=ticketId; 
    END;

