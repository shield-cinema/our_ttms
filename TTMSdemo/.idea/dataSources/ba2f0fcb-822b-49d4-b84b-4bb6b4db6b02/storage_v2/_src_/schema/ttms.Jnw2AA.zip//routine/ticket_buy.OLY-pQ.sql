create
    definer = root@localhost procedure ticket_buy(IN ticketId mediumtext, IN schedId int)
BEGIN
	UPDATE ticket SET ticket_status=9 WHERE ticket_id=ticketId AND sched_id=schedId;
	UPDATE ticket SET ticket_locked_time='1900-01-01 00:00:00' WHERE ticket_id=ticketId AND sched_id=schedId;
    END;

